<!-- FOOTER -->
      <footer>
        <div class="container">
          <div class="row">
            <div class="col-lg-12 text-center">
              <p id="copyright"></p>
              <hr>
            </div>
            <div class="col-lg-12 text-center">
              <a id= "fb" href="" target ="_blank"></i></a>
              <a id="ig" href="" target="_blank"></a>
            </div>
          </div>
        </div>
        <p class="pull-right"><a href="#">Back to top</a></p>
      </footer>

    </div><!-- /.container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="<?php bloginfo('template_directory');?>/js/jquery.js"></script>

    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php bloginfo('template_directory');?>/js/bootstrap.min.js"></script>

    <script>
      $('.carousel').carousel({
          interval: 000 //changes the speed
      })
    </script>
    <span id="google"></span>
    <?php wp_footer(); ?>
  </body>
</html>